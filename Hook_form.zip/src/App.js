import logo from './logo.svg';
import './App.css';
import UserForm from './components/User'

function App() {
  return (
    <div className="App">
      <UserForm></UserForm>

    </div>
  );
}

export default App;





    